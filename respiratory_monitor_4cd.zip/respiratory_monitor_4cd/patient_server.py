#!/usr/bin/env python3
"""
Patient Display Server – runs on port 8000
Serves the respiratory visualizer with threshold lines synced from the dashboard.
"""

from flask import Flask, render_template_string
import webbrowser

app = Flask(__name__)

PATIENT_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Patient Respiratory Monitor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        :root {
            --bg-base: #060e1a;
            --bg-panel: #0b1628;
            --border: rgba(0,212,200,0.15);
            --border-dim: rgba(255,255,255,0.06);
            --teal: #00d4c8;
            --teal-dim: rgba(0,212,200,0.12);
            --green: #00e676;
            --red: #ff3b5c;
            --amber: #ffb547;
            --text-primary: #e8f0fe;
            --text-secondary: #8faac8;
            --text-muted: #4a6080;
            --font-mono: 'JetBrains Mono', monospace;
            --font-ui: 'Inter', sans-serif;
        }
        body {
            font-family: var(--font-ui);
            background: var(--bg-base);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-primary);
            padding: 20px;
        }
        body::before {
            content: '';
            position: fixed; inset: 0;
            background-image: linear-gradient(rgba(0,212,200,0.02) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(0,212,200,0.02) 1px, transparent 1px);
            background-size: 40px 40px;
            pointer-events: none; z-index:0;
        }
        .patient-container {
            position: relative; z-index:1;
            background: var(--bg-panel);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 30px 40px 40px;
            max-width: 620px;
            width: 100%;
            box-shadow: 0 0 60px rgba(0,0,0,0.6), inset 0 1px 0 rgba(0,212,200,0.1);
            display: flex; flex-direction: column; align-items: center;
        }
        .patient-container::before {
            content: '';
            position: absolute; top:0; left:0; right:0; height:2px;
            background: linear-gradient(90deg, transparent 0%, var(--teal) 30%, var(--teal) 32%, transparent 34%, transparent 38%, var(--teal) 39%, transparent 41%, transparent 100%);
            background-size: 200% 100%;
            animation: ecgScan 3s linear infinite;
            opacity:0.8;
            border-radius: 16px 16px 0 0;
        }
        @keyframes ecgScan { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
        .patient-header {
            display: flex; justify-content: space-between; width:100%;
            margin-bottom:20px; padding-bottom:12px;
            border-bottom: 1px solid var(--border-dim);
        }
        .patient-title {
            display: flex; align-items:center; gap:10px;
            font-family: var(--font-mono); font-size:0.75rem;
            letter-spacing:0.1em; text-transform:uppercase;
            color: var(--teal);
        }
        .status-dot {
            width:8px; height:8px; border-radius:50%;
            background: var(--text-muted);
            transition: background 0.3s;
        }
        .status-dot.connected { background: var(--green); box-shadow: 0 0 10px var(--green); }
        .patient-zero {
            font-family: var(--font-mono); font-size:0.65rem;
            color: var(--text-muted);
            background: rgba(0,0,0,0.3);
            padding: 4px 12px; border-radius:4px;
            border: 1px solid var(--border-dim);
        }
        .cylinder-wrapper {
            position: relative;
            display: flex; flex-direction: column; align-items:center;
            width:100%; margin:10px 0 20px;
        }
        .lung-glow-ring {
            position: absolute;
            width: 280px; height: 380px;
            border: 1px solid rgba(0,212,200,0.12);
            border-radius: 140px / 70px;
            box-shadow: 0 0 40px rgba(0,212,200,0.06), inset 0 0 40px rgba(0,212,200,0.03);
            pointer-events: none;
        }
        .cylinder {
            position: relative;
            width: 220px; height: 340px;
            background: linear-gradient(180deg, #0a1f35 0%, #0d2a48 40%, #0a1f35 100%);
            border-radius: 110px / 55px;
            box-shadow: inset -6px 0 20px rgba(0,0,0,0.5), inset 6px 0 12px rgba(0,212,200,0.06), 0 10px 40px rgba(0,0,0,0.4);
            overflow: hidden;
        }
        .cylinder::after {
            content: '';
            position: absolute; left:26px; top:0; bottom:0; width:20px;
            background: linear-gradient(180deg, rgba(0,212,200,0.12) 0%, rgba(0,212,200,0.05) 50%, rgba(0,212,200,0.12) 100%);
            border-radius:50%;
        }
        .cylinder-cap-top {
            position: absolute; top:-18px; left:50%; transform:translateX(-50%);
            width:220px; height:36px;
            background: radial-gradient(ellipse at center, rgba(0,212,200,0.35) 0%, rgba(0,212,200,0.05) 70%, transparent 100%);
            border-radius:50%;
        }
        .cylinder-cap-bottom {
            position: absolute; bottom:-18px; left:50%; transform:translateX(-50%);
            width:220px; height:36px;
            background: radial-gradient(ellipse at center, rgba(0,0,0,0.6) 0%, transparent 70%);
            border-radius:50%;
        }
        .cylinder-ticks {
            position: absolute; right:12px; top:30px; bottom:30px;
            display: flex; flex-direction: column; justify-content:space-between;
        }
        .cylinder-tick { width:10px; height:1px; background: rgba(0,212,200,0.2); }
        .moving-ring {
            position: absolute;
            width: 240px; height: 14px; left: -10px;
            background: linear-gradient(90deg, transparent, var(--teal), var(--teal), transparent);
            border-radius: 7px;
            transition: top 0.05s linear, background 0.2s ease, box-shadow 0.2s ease;
            box-shadow: 0 0 20px rgba(0,212,200,0.9), 0 0 50px rgba(0,212,200,0.4);
            z-index: 10;
        }
        .moving-ring.over-limit {
            background: linear-gradient(90deg, transparent, var(--red), var(--red), transparent);
            box-shadow: 0 0 20px rgba(255,59,92,0.9), 0 0 50px rgba(255,59,92,0.4);
        }
        /* Threshold lines */
        .viz-threshold-line {
            position: absolute;
            left: -10px;
            width: 240px;
            height: 0;
            border-top: 2px dashed;
            z-index: 8;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .viz-threshold-line.active { opacity: 1; }
        .viz-threshold-line.inhale { border-color: var(--green); }
        .viz-threshold-line.exhale { border-color: var(--red); }
        .viz-threshold-label {
            position: absolute;
            right: -48px; top: -8px;
            font-family: var(--font-mono);
            font-size: 0.55rem;
            white-space: nowrap;
            color: var(--text-secondary);
            background: var(--bg-panel);
            padding: 0 4px;
        }
        .cylinder-scale {
            position: absolute; right:-50px; top:0; bottom:0;
            display:flex; flex-direction:column; justify-content:space-between;
            padding:14px 0;
        }
        .scale-label {
            font-family: var(--font-mono); font-size:0.65rem;
            color: var(--text-muted); line-height:1;
        }
        .phase-readout {
            margin-top: 28px;
            display: flex; flex-direction: column; align-items:center; gap:8px;
        }
        .phase-text {
            font-family: var(--font-mono); font-size:1.4rem; font-weight:700;
            letter-spacing:0.15em; text-transform:uppercase;
            transition: color 0.15s;
        }
        .phase-inhale { color: var(--green); text-shadow: 0 0 20px rgba(0,230,118,0.6); }
        .phase-exhale { color: var(--red); text-shadow: 0 0 20px rgba(255,59,92,0.6); }
        .phase-pause  { color: var(--amber); text-shadow: 0 0 20px rgba(255,181,71,0.6); }
        .phase-legend {
            display: flex; gap:20px; margin-top:2px;
        }
        .phase-legend-item {
            display: flex; align-items:center; gap:6px;
            font-family: var(--font-mono); font-size:0.65rem;
            color: var(--text-muted);
        }
        .phase-legend-dot { width:8px; height:8px; border-radius:50%; }
        .current-display {
            font-family: var(--font-mono); font-size:2rem; font-weight:600;
            color: var(--text-secondary); margin-top:4px;
            letter-spacing:0.05em;
        }
        .current-display span { color: var(--teal); }
        .footer-note {
            margin-top:20px;
            font-family: var(--font-mono); font-size:0.6rem;
            color: var(--text-muted);
            border-top:1px solid var(--border-dim);
            padding-top:16px; width:100%; text-align:center;
        }

        /* ── Session-expired banner ── */
        .session-banner {
            display: none;
            width: 100%;
            background: rgba(255,59,92,0.1);
            border: 1px solid rgba(255,59,92,0.4);
            color: var(--red);
            font-family: var(--font-mono);
            font-size: 0.65rem;
            letter-spacing: 0.04em;
            text-align: center;
            line-height: 1.5;
            padding: 10px 14px;
            border-radius: 6px;
            margin-bottom: 16px;
        }
        .session-banner.active { display: block; }

        /* ── Timer pane (mirrors dashboard "Relay Timer" pane, lower-right) ── */
        .timer-section {
            width: 100%;
            margin-top: 24px;
            padding-top: 18px;
            border-top: 1px solid var(--border-dim);
        }
        .timer-section-title {
            display: flex; align-items: center; justify-content:center; gap: 8px;
            font-family: var(--font-mono); font-size:0.65rem;
            letter-spacing:0.1em; text-transform:uppercase;
            color: var(--text-secondary);
            margin-bottom: 14px;
        }
        .timer-pane {
            display: flex; flex-direction: column;
            align-items: center; justify-content: center;
            gap: 12px;
        }
        .timer-label {
            font-family: var(--font-mono);
            font-size: 0.6rem; letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--text-muted); font-weight: 600;
        }
        .timer-ring-wrap {
            position: relative;
            display: flex; align-items: center; justify-content: center;
        }
        .timer-ring-svg {
            position: absolute;
            width: 140px; height: 140px;
            transform: rotate(-90deg);
        }
        .timer-ring-bg {
            fill: none;
            stroke: rgba(255,255,255,0.05);
            stroke-width: 3;
        }
        .timer-ring-fill {
            fill: none;
            stroke: var(--teal);
            stroke-width: 3;
            stroke-linecap: round;
            stroke-dasharray: 440;
            stroke-dashoffset: 440;
            transition: stroke 0.3s;
        }
        .timer-ring-fill.running { stroke: var(--green); }
        .timer-ring-fill.stopped { stroke: var(--amber); }
        .timer-display {
            font-family: var(--font-mono);
            font-size: 2.6rem; font-weight: 700;
            letter-spacing: 0.02em;
            font-variant-numeric: tabular-nums;
            transition: color 0.3s, text-shadow 0.3s;
        }
        .timer-display.running {
            color: var(--green);
            text-shadow: 0 0 26px rgba(0,230,118,0.5);
        }
        .timer-display.stopped {
            color: var(--amber);
            text-shadow: 0 0 26px rgba(255,181,71,0.5);
        }
        .timer-display.idle {
            color: rgba(255,255,255,0.15);
            text-shadow: none;
        }
        .timer-state-badge {
            padding: 4px 16px;
            border-radius: 20px;
            font-family: var(--font-mono);
            font-size: 0.62rem; font-weight: 700;
            letter-spacing: 0.12em; text-transform: uppercase;
        }
        .timer-state-badge.idle    { background: rgba(255,255,255,0.05); color: var(--text-muted); border: 1px solid var(--border-dim); }
        .timer-state-badge.running { background: rgba(0,230,118,0.15); color: var(--green); border: 1px solid rgba(0,230,118,0.35); }
        .timer-state-badge.stopped { background: rgba(255,181,71,0.15); color: var(--amber); border: 1px solid rgba(255,181,71,0.35); }
        .timer-sub {
            font-family: var(--font-mono);
            font-size: 0.6rem;
            color: var(--text-muted);
            text-align: center;
            max-width: 240px; line-height: 1.6;
            letter-spacing: 0.02em;
        }
        @media (max-width:480px) {
            .patient-container { padding:20px 16px 30px; }
            .cylinder { width:180px; height:280px; border-radius:90px / 45px; }
            .moving-ring { width:200px; left:-10px; height:12px; }
            .cylinder-cap-top, .cylinder-cap-bottom { width:180px; }
            .lung-glow-ring { width:230px; height:320px; border-radius:115px / 60px; }
            .cylinder-scale { right:-40px; }
            .scale-label { font-size:0.55rem; }
            .phase-text { font-size:1.1rem; }
            .current-display { font-size:1.6rem; }
            .viz-threshold-line { width:200px; left:-10px; }
            .timer-ring-svg { width:120px; height:120px; }
            .timer-display { font-size:2.1rem; }
        }
    </style>
</head>
<body>
    <div class="patient-container">
        <div class="patient-header">
            <div class="patient-title">
                <i class="fas fa-lungs" style="color:var(--teal);"></i>
                Patient Monitor
                <span class="status-dot" id="statusDot"></span>
            </div>
            <div class="patient-zero" id="zeroDisplay">Zero: -- cm</div>
        </div>

        <div class="session-banner" id="sessionBanner">
            <i class="fas fa-hourglass-end" style="margin-right:6px;"></i>
            <span id="sessionBannerText">Session limit reached — awaiting recalibration.</span>
        </div>

        <div class="cylinder-wrapper">
            <div class="lung-glow-ring"></div>
            <div class="cylinder">
                <div class="cylinder-ticks">
                    <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                    <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                    <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                    <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                    <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                    <div class="cylinder-tick"></div>
                </div>
                <!-- Threshold lines -->
                <div class="viz-threshold-line inhale" id="vizThresholdInhaleMin">
                    <span class="viz-threshold-label" id="vizThresholdInhaleMinLabel">Inhale Min</span>
                </div>
                <div class="viz-threshold-line inhale" id="vizThresholdInhaleMax">
                    <span class="viz-threshold-label" id="vizThresholdInhaleMaxLabel">Inhale Max</span>
                </div>
                <div class="viz-threshold-line exhale" id="vizThresholdExhaleMin">
                    <span class="viz-threshold-label" id="vizThresholdExhaleMinLabel">Exhale Min</span>
                </div>
                <div class="viz-threshold-line exhale" id="vizThresholdExhaleMax">
                    <span class="viz-threshold-label" id="vizThresholdExhaleMaxLabel">Exhale Max</span>
                </div>
                <div class="moving-ring" id="movingRing" style="top:50%;"></div>
            </div>
            <div class="cylinder-cap-top"></div>
            <div class="cylinder-cap-bottom"></div>
            <div class="cylinder-scale">
                <span class="scale-label">+4</span>
                <span class="scale-label">+2</span>
                <span class="scale-label"> 0</span>
                <span class="scale-label">-2</span>
                <span class="scale-label">-4</span>
            </div>
        </div>

        <div class="phase-readout">
            <div class="phase-text phase-pause" id="phaseText">WAITING</div>
            <div class="phase-legend">
                <div class="phase-legend-item"><div class="phase-legend-dot" style="background:var(--green);"></div>INHALE ↑</div>
                <div class="phase-legend-item"><div class="phase-legend-dot" style="background:var(--red);"></div>EXHALE ↓</div>
                <div class="phase-legend-item"><div class="phase-legend-dot" style="background:var(--amber);"></div>PAUSE</div>
            </div>
        </div>

        <div class="current-display">
            <span id="currentDispVal">0</span> cm
        </div>

        <div class="timer-section">
            <div class="timer-section-title">
                <i class="fas fa-stopwatch" style="color:var(--teal);"></i> Relay Timer
            </div>
            <div class="timer-pane">
                <div class="timer-label">Relay Active Duration</div>
                <div class="timer-ring-wrap">
                    <svg class="timer-ring-svg" viewBox="0 0 160 160">
                        <circle class="timer-ring-bg" cx="80" cy="80" r="70"/>
                        <circle class="timer-ring-fill" id="timerRingFill" cx="80" cy="80" r="70"/>
                    </svg>
                    <div class="timer-display idle" id="timerDisplay">00:00.0</div>
                </div>
                <div class="timer-state-badge idle" id="timerBadge">IDLE</div>
                <div class="timer-sub" id="timerSub">
                    Waiting for relay to activate.<br>
                    Calibrate zero to reset timer.
                </div>
            </div>
        </div>

        <div class="footer-note">
            <i class="fas fa-satellite-dish" style="margin-right:6px;"></i>
            Live from respiratory sensor &bull; v1.0
        </div>
    </div>

    <script>
        // ── Socket connection to main backend ──
        const socket = io('http://localhost:5000');

        // ── DOM refs ──
        const statusDot = document.getElementById('statusDot');
        const phaseText = document.getElementById('phaseText');
        const movingRing = document.getElementById('movingRing');
        const currentDispVal = document.getElementById('currentDispVal');
        const zeroDisplay = document.getElementById('zeroDisplay');
        const sessionBanner = document.getElementById('sessionBanner');
        const sessionBannerText = document.getElementById('sessionBannerText');

        // Threshold line elements
        const inhaleMinLine = document.getElementById('vizThresholdInhaleMin');
        const inhaleMaxLine = document.getElementById('vizThresholdInhaleMax');
        const exhaleMinLine = document.getElementById('vizThresholdExhaleMin');
        const exhaleMaxLine = document.getElementById('vizThresholdExhaleMax');
        const inhaleMinLabel = document.getElementById('vizThresholdInhaleMinLabel');
        const inhaleMaxLabel = document.getElementById('vizThresholdInhaleMaxLabel');
        const exhaleMinLabel = document.getElementById('vizThresholdExhaleMinLabel');
        const exhaleMaxLabel = document.getElementById('vizThresholdExhaleMaxLabel');

        // ── Visualizer constants ──
        const VIZ_MAX_D = 4;
        const VIZ_MIN_TOP = 50;   // top for +4 cm
        const VIZ_MAX_TOP = 290;  // top for -4 cm

        function vizPositionForValue(v) {
            const clamped = Math.max(-VIZ_MAX_D, Math.min(VIZ_MAX_D, v));
            const norm = (clamped + VIZ_MAX_D) / (2 * VIZ_MAX_D);
            return VIZ_MAX_TOP - (norm * (VIZ_MAX_TOP - VIZ_MIN_TOP));
        }

        // ── Threshold storage ──
        let thresholds = {
            inhale: { min: null, max: null },
            exhale: { min: null, max: null }
        };

        function updateThresholdLines() {
            // Helper to set a line
            function setLine(el, labelEl, value, phase, labelPrefix) {
                if (value === null || value === undefined) {
                    el.classList.remove('active');
                    return;
                }
                el.style.top = `${vizPositionForValue(value)}px`;
                el.classList.add('active');
                labelEl.textContent = `${labelPrefix} ${value.toFixed(1)} cm`;
            }

            const inh = thresholds.inhale;
            const exh = thresholds.exhale;

            setLine(inhaleMinLine, inhaleMinLabel, inh.min, 'inhale', 'Inhale Min');
            setLine(inhaleMaxLine, inhaleMaxLabel, inh.max, 'inhale', 'Inhale Max');
            setLine(exhaleMinLine, exhaleMinLabel, exh.min, 'exhale', 'Exhale Min');
            setLine(exhaleMaxLine, exhaleMaxLabel, exh.max, 'exhale', 'Exhale Max');
        }

        // ── Over-limit check (same idea as the dashboard waveform turning red:
        // positive displacement is checked against the Inhale Max line, negative
        // displacement against the Exhale Max line) ──
        function isPastMaxLimit(v) {
            if (v >= 0) {
                const m = thresholds.inhale.max;
                return (m !== null && m !== undefined) && v > m;
            } else {
                const m = thresholds.exhale.max;
                return (m !== null && m !== undefined) && Math.abs(v) > m;
            }
        }

        /* ─────────────────────────────────────────────────────────
           RELAY TIMER PANE — mirrors the dashboard's lower-right
           "Relay Timer" pane with identical logic. This display never
           initiates timer changes itself; it only reflects the
           timer_active state broadcast by the backend.
        ───────────────────────────────────────────────────────── */
        let timerRunning     = false;
        let timerStartMs     = null;
        let timerFrozenValue = null;
        let timerRAF         = null;
        let lastTimerActive  = false;

        function fmtTime(ms) {
            const total = ms / 1000;
            const m = Math.floor(total / 60);
            const s = Math.floor(total % 60);
            const d = Math.floor((total % 1) * 10);
            return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${d}`;
        }

        function startTimer() {
            timerFrozenValue = null;
            timerStartMs = Date.now();
            timerRunning = true;
            const el  = document.getElementById('timerDisplay');
            const bdg = document.getElementById('timerBadge');
            const sub = document.getElementById('timerSub');
            const ring = document.getElementById('timerRingFill');
            el.className  = 'timer-display running';
            bdg.className = 'timer-state-badge running';
            bdg.textContent = 'RUNNING';
            ring.className = 'timer-ring-fill running';
            sub.textContent = 'Relay is active. Timer counts relay-on duration.';
            function tick() {
                if (!timerRunning) return;
                el.textContent = fmtTime(Date.now() - timerStartMs);
                timerRAF = requestAnimationFrame(tick);
            }
            cancelAnimationFrame(timerRAF);
            timerRAF = requestAnimationFrame(tick);
        }

        function stopTimer() {
            timerRunning = false;
            cancelAnimationFrame(timerRAF);
            const el  = document.getElementById('timerDisplay');
            const bdg = document.getElementById('timerBadge');
            const sub = document.getElementById('timerSub');
            const ring = document.getElementById('timerRingFill');
            if (timerStartMs) { timerFrozenValue = Date.now() - timerStartMs; el.textContent = fmtTime(timerFrozenValue); }
            el.className  = timerFrozenValue ? 'timer-display stopped' : 'timer-display idle';
            bdg.className = timerFrozenValue ? 'timer-state-badge stopped' : 'timer-state-badge idle';
            bdg.textContent = timerFrozenValue ? 'STOPPED' : 'IDLE';
            ring.className = timerFrozenValue ? 'timer-ring-fill stopped' : 'timer-ring-fill';
            sub.textContent = timerFrozenValue
                ? 'Showing last relay-on duration. Calibrate zero to reset.'
                : 'Waiting for relay to activate. Calibrate zero to reset timer.';
        }

        function resetTimer() {
            timerRunning = false; timerStartMs = null; timerFrozenValue = null;
            cancelAnimationFrame(timerRAF);
            const el  = document.getElementById('timerDisplay');
            const bdg = document.getElementById('timerBadge');
            const sub = document.getElementById('timerSub');
            const ring = document.getElementById('timerRingFill');
            el.textContent = '00:00.0';
            el.className  = 'timer-display idle';
            bdg.className = 'timer-state-badge idle';
            bdg.textContent = 'IDLE';
            ring.className = 'timer-ring-fill';
            ring.style.strokeDashoffset = '440';
            sub.textContent = 'Waiting for relay to activate. Calibrate zero to reset timer.';
            lastTimerActive = false;
        }

        // ── Socket events ──
        socket.on('connect', () => {
            statusDot.className = 'status-dot connected';
            phaseText.innerHTML = 'CONNECTED';
            phaseText.className = 'phase-text phase-pause';
            // Sync current relay/timer state immediately (in case a session is already running)
            socket.emit('get_relay_status');
        });

        socket.on('disconnect', () => {
            statusDot.className = 'status-dot';
            phaseText.innerHTML = 'DISCONNECTED';
            phaseText.className = 'phase-text phase-pause';
        });

        socket.on('calibration_complete', (data) => {
            if (data && data.zero_value !== undefined) {
                zeroDisplay.textContent = `Zero: ${data.zero_value} cm`;
            }
            sessionBanner.classList.remove('active');
            resetTimer();
        });

        socket.on('calibration_status', (data) => {
            if (data.calibrated && data.zero_value !== undefined) {
                zeroDisplay.textContent = `Zero: ${data.zero_value} cm`;
                sessionBanner.classList.remove('active');
                resetTimer();
            } else {
                zeroDisplay.textContent = 'Zero: -- cm';
            }
        });

        socket.on('sensor_data', (data) => {
            if (data.displacement !== undefined) {
                const disp = data.displacement;
                movingRing.style.top = `${vizPositionForValue(disp)}px`;
                movingRing.classList.toggle('over-limit', isPastMaxLimit(disp));
                currentDispVal.textContent = Math.round(disp);

                if (disp >= 1) {
                    phaseText.innerHTML = 'INHALING ↑';
                    phaseText.className = 'phase-text phase-inhale';
                } else if (disp <= -1) {
                    phaseText.innerHTML = 'EXHALING ↓';
                    phaseText.className = 'phase-text phase-exhale';
                } else {
                    phaseText.innerHTML = 'PAUSE ●';
                    phaseText.className = 'phase-text phase-pause';
                }
            }
        });

        // ── Mirror relay timer state from the backend (no local control —
        // this display only reflects what the dashboard/backend reports) ──
        socket.on('relay_status_update', (data) => {
            const active = !!data.timer_active;
            if (active && !lastTimerActive) {
                startTimer();
            } else if (!active && lastTimerActive) {
                stopTimer();
            }
            lastTimerActive = active;
        });

        // ── 15-minute session limit reached — demand recalibration ──
        socket.on('session_expired', (data) => {
            sessionBannerText.textContent = data.message || 'Session time limit reached. Please calibrate again.';
            sessionBanner.classList.add('active');
            zeroDisplay.textContent = 'Zero: -- cm';
            movingRing.style.top = `${vizPositionForValue(0)}px`;
            movingRing.classList.remove('over-limit');
            phaseText.innerHTML = 'AWAITING RECALIBRATION';
            phaseText.className = 'phase-text phase-pause';
            stopTimer();
            resetTimer();
        });

        // ── Listen for threshold updates from dashboard ──
        socket.on('thresholds_updated', (data) => {
            const phase = data.phase;
            if (phase === 'inhale' || phase === 'exhale') {
                thresholds[phase].min = data.min;
                thresholds[phase].max = data.max;
                updateThresholdLines();
                console.log(`Thresholds updated for ${phase}: ${data.min} – ${data.max} cm`);
            }
        });

        // ── Initial state ──
        movingRing.style.top = `${vizPositionForValue(0)}px`;
        updateThresholdLines(); // hides all lines initially
        resetTimer();
    </script>
</body>
</html>
"""

@app.route('/')
def patient_display():
    return render_template_string(PATIENT_HTML)

if __name__ == '__main__':
    print("\n" + "=" * 50)
    print(" PATIENT DISPLAY SERVER")
    print(" Serving on http://localhost:8000")
    print(" Ensure the main backend is running on port 5000")
    print("=" * 50 + "\n")
    webbrowser.open('http://localhost:8000')
    app.run(host='0.0.0.0', port=8000, debug=False)
