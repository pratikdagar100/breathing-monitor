#!/usr/bin/env python3
"""
Respiratory Monitor Backend with WebSocket Streaming
Sensor  : VL53L4CD (replaces VL53L0X)
Readings: Centimeters (cm) - Integer Values
          VL53L4CD returns distance in cm natively — no mm→cm conversion needed.
Calibration: FAST (5 samples only - NO 30 SAMPLES!)
Runs on Raspberry Pi 4B
"""

import time
import board
import busio
import adafruit_vl53l4cd
import numpy as np
from collections import deque
from flask import Flask, render_template, send_from_directory
from flask_socketio import SocketIO, emit
from threading import Lock
import eventlet

eventlet.monkey_patch()

# ----------------------------
# Noise Filter Class
# ----------------------------
class NoiseFilter:
    def __init__(self, window_size=7, alpha=0.3):
        self.window_size = window_size
        self.alpha = alpha
        self.buffer = deque(maxlen=window_size)
        self.filtered_value = None

    def apply(self, raw_value):
        self.buffer.append(raw_value)
        median_val = np.median(self.buffer)
        
        if self.filtered_value is None:
            self.filtered_value = median_val
        else:
            self.filtered_value = self.alpha * median_val + (1 - self.alpha) * self.filtered_value
        
        return self.filtered_value

# ----------------------------
# Sensor Reader
# ----------------------------
class RespiratorySensor:
    def __init__(self):
        try:
            self.i2c = busio.I2C(board.SCL, board.SDA)
            # VL53L4CD — different library, no timing-budget setting needed
            self.sensor = adafruit_vl53l4cd.VL53L4CD(self.i2c)
            self.sensor.start_ranging()          # VL53L4CD must be told to start
            self.filter = NoiseFilter(window_size=5, alpha=0.3)
            self.reference_zero = None           # stored in cm (float)
            self.calibrated = False
            print("VL53L4CD sensor initialized successfully")
        except Exception as e:
            print(f"Sensor init error: {e}")
            self.sensor = None

    # ------------------------------------------------------------------
    # Internal helper — blocks until one valid reading arrives (cm)
    # VL53L4CD returns distance in cm natively (float), so NO /10 needed.
    # ------------------------------------------------------------------
    def _read_one_cm(self, timeout=0.5):
        """Wait for data_ready, read distance in cm, clear interrupt."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                if self.sensor.data_ready:
                    dist_cm = self.sensor.distance   # already in cm
                    self.sensor.clear_interrupt()
                    if dist_cm is not None and 0 < dist_cm < 200:
                        return dist_cm
            except Exception:
                pass
            time.sleep(0.1)
        return None

    def calibrate_zero(self):
        """FAST calibration - ONLY 5 SAMPLES - NOT 30!"""
        if not self.sensor:
            return False

        print("\n" + "=" * 50)
        print("FAST CALIBRATION - Please keep person perfectly still")
        print("=" * 50)

        samples_cm = []
        print("Taking ONLY 5 quick samples...")

        for i in range(5):
            dist = self._read_one_cm()
            if dist is not None:
                samples_cm.append(dist)
                print(f"  Sample {i+1}: {dist:.1f} cm")
            time.sleep(0.1)

        if len(samples_cm) >= 3:
            self.reference_zero = float(np.median(samples_cm))
            self.calibrated = True
            zero_cm = int(round(self.reference_zero))
            print(f"\n✓ Calibration complete!")
            print(f"  Reference Zero: {self.reference_zero:.1f} cm")
            print(f"  Samples used: {len(samples_cm)}")
            print("=" * 50 + "\n")
            return True
        else:
            print(f"\n✗ Calibration failed! Only {len(samples_cm)} valid samples.")
            print("=" * 50 + "\n")
            return False

    def get_displacement(self):
        """Get relative displacement - returns INTEGER in CM.
        Positive  → chest moved toward sensor (inhale).
        Negative  → chest moved away from sensor (exhale).
        """
        if not self.sensor or not self.calibrated:
            return 0

        dist_cm = self._read_one_cm()
        if dist_cm is None:
            return 0

        try:
            filtered_cm = self.filter.apply(dist_cm)
            # reference_zero is the resting (baseline) distance in cm
            displacement_cm = self.reference_zero - filtered_cm
            # Clamp to ±3 cm (reasonable chest-wall travel range)
            displacement_cm = max(-3.0, min(3.0, displacement_cm))
            return int(round(displacement_cm))
        except Exception as e:
            print(f"Displacement error: {e}")
            return 0

# ----------------------------
# Flask App with SocketIO
# ----------------------------
app = Flask(__name__)
app.config['SECRET_KEY'] = 'respiratory_monitor_secret'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

sensor = RespiratorySensor()
streaming = False

class DummyPatient:
    def __init__(self):
        self.heart_rate = 72
        self.breathing_rate = 16
        self.temperature = 36.8
        self.spo2 = 98
        self.systolic = 118
        self.diastolic = 78

dummy_patient = DummyPatient()

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

@socketio.on('connect')
def handle_connect(auth=None):
    print('Client connected')
    emit('calibration_status', {'calibrated': sensor.calibrated})
    emit('patient_data', {
        'heart_rate': dummy_patient.heart_rate,
        'breathing_rate': dummy_patient.breathing_rate,
        'temperature': dummy_patient.temperature,
        'spo2': dummy_patient.spo2,
        'blood_pressure': f"{dummy_patient.systolic}/{dummy_patient.diastolic}"
    })

@socketio.on('calibrate')
def handle_calibration():
    print("Starting FAST calibration (5 samples only)...")
    success = sensor.calibrate_zero()
    emit('calibration_status', {'calibrated': success})
    if success:
        zero_cm = int(round(sensor.reference_zero)) if sensor.reference_zero else 0
        emit('calibration_complete', {
            'zero_value': zero_cm,
            'message': f"Zero set to {zero_cm} cm"
        })
    return success

@socketio.on('start_streaming')
def handle_start_streaming():
    global streaming
    streaming = True
    print("\n" + "=" * 50)
    print("STREAMING STARTED - Readings in cm (INTEGERS)")
    print("=" * 50 + "\n")
    
    def stream_data():
        last_debug_time = time.time()
        frame_count = 0
        
        while streaming:
            displacement = sensor.get_displacement()
            
            if displacement >= 1:
                phase = "INHALING"
            elif displacement <= -1:
                phase = "EXHALING"
            else:
                phase = "PAUSE"
            
            socketio.emit('sensor_data', {
                'displacement': displacement,
                'phase': phase,
                'timestamp': time.time()
            })
            
            dummy_patient.breathing_rate = 12 + abs(displacement) * 2
            socketio.emit('patient_data', {
                'heart_rate': dummy_patient.heart_rate + np.random.randn() * 2,
                'breathing_rate': max(8, min(25, dummy_patient.breathing_rate)),
                'temperature': dummy_patient.temperature + np.random.randn() * 0.1,
                'spo2': min(100, max(90, dummy_patient.spo2 + np.random.randn() * 0.5)),
                'blood_pressure': f"{dummy_patient.systolic + int(np.random.randn() * 3)}/{dummy_patient.diastolic + int(np.random.randn() * 2)}"
            })
            
            frame_count += 1
            current_time = time.time()
            if current_time - last_debug_time >= 2.0:
                print(f"[Stream] Displacement: {displacement:+d} cm | Phase: {phase} | Rate: {frame_count/2:.1f} Hz")
                last_debug_time = current_time
                frame_count = 0
            
            time.sleep(0.1)
    
    socketio.start_background_task(stream_data)

@socketio.on('stop_streaming')
def handle_stop_streaming():
    global streaming
    streaming = False
    print("\nSTREAMING STOPPED\n")

if __name__ == '__main__':
    print("\n" + "=" * 60)
    print(" RESPIRATORY MONITOR SERVER - VL53L4CD SENSOR")
    print(" FAST CALIBRATION — ONLY 5 SAMPLES!")
    print(" READINGS IN CENTIMETERS (cm) — INTEGER VALUES")
    print(" VL53L4CD returns cm natively (no mm conversion)")
    print("=" * 60)
    
    if sensor.sensor:
        print("✓ VL53L4CD sensor detected")
        try:
            dist = sensor._read_one_cm(timeout=1.0)
            if dist is not None:
                print(f"  Test reading: {dist:.1f} cm")
        except:
            pass
    else:
        print("⚠ WARNING: VL53L4CD sensor not detected!")
        print("  Check wiring: SDA→GPIO2, SCL→GPIO3, VIN→3.3 V, GND→GND")
    
    print("\nAccess the dashboard at:")
    print("  • http://localhost:5000")
    print("  • http://<YOUR_RASPBERRY_PI_IP>:5000")
    print("=" * 60)
    print("\nINSTRUCTIONS:")
    print("1. Click 'Calibrate Zero' — ONLY 5 SAMPLES (takes <1 second!)")
    print("2. Click 'Start Monitoring' to begin")
    print("=" * 60 + "\n")
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
