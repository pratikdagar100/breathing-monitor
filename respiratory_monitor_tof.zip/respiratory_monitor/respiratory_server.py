#!/usr/bin/env python3
"""
Respiratory Monitor Backend with WebSocket Streaming
Readings in Centimeters (cm) - Integer Values
FAST CALIBRATION (5 samples only - NO 30 SAMPLES!)
Runs on Raspberry Pi 4B
"""

import time
import board
import busio
import adafruit_vl53l0x
import numpy as np
from collections import deque
from flask import Flask, render_template, send_from_directory
from flask_socketio import SocketIO, emit
from threading import Lock
import eventlet

eventlet.monkey_patch()

# ----------------------------
# Noise Filter Class
# ----------------------------
class NoiseFilter:
    def __init__(self, window_size=7, alpha=0.3):
        self.window_size = window_size
        self.alpha = alpha
        self.buffer = deque(maxlen=window_size)
        self.filtered_value = None

    def apply(self, raw_value):
        self.buffer.append(raw_value)
        median_val = np.median(self.buffer)
        
        if self.filtered_value is None:
            self.filtered_value = median_val
        else:
            self.filtered_value = self.alpha * median_val + (1 - self.alpha) * self.filtered_value
        
        return self.filtered_value

# ----------------------------
# Sensor Reader
# ----------------------------
class RespiratorySensor:
    def __init__(self):
        try:
            self.i2c = busio.I2C(board.SCL, board.SDA)
            self.sensor = adafruit_vl53l0x.VL53L0X(self.i2c)
            self.sensor.measurement_timing_budget_us = 20000
            self.filter = NoiseFilter(window_size=5, alpha=0.3)
            self.reference_zero = None
            self.calibrated = False
            print("Sensor initialized successfully")
        except Exception as e:
            print(f"Sensor init error: {e}")
            self.sensor = None
    
    def calibrate_zero(self):
        """FAST calibration - ONLY 5 SAMPLES - NOT 30!"""
        if not self.sensor:
            return False
        
        print("\n" + "=" * 50)
        print("FAST CALIBRATION - Please keep person perfectly still")
        print("=" * 50)
        
        samples_mm = []
        print("Taking ONLY 5 quick samples...")
        
        # ONLY 5 SAMPLES - THIS IS WHAT YOU WANT
        for i in range(5):
            try:
                dist = self.sensor.range
                if dist and dist > 0 and dist < 2000:
                    samples_mm.append(dist)
                    print(f"  Sample {i+1}: {dist:.1f} mm ({int(round(dist/10))} cm)")
                time.sleep(0.1)
            except:
                pass
        
        if len(samples_mm) >= 3:
            self.reference_zero = np.median(samples_mm)
            self.calibrated = True
            zero_cm = int(round(self.reference_zero / 10))
            print(f"\n✓ Calibration complete!")
            print(f"  Reference Zero: {self.reference_zero:.1f} mm ({zero_cm} cm)")
            print(f"  Samples used: {len(samples_mm)}")
            print("=" * 50 + "\n")
            return True
        else:
            print(f"\n✗ Calibration failed! Only {len(samples_mm)} valid samples.")
            print("=" * 50 + "\n")
            return False
    
    def get_displacement(self):
        """Get relative displacement - returns INTEGER in CM"""
        if not self.sensor or not self.calibrated:
            return 0
        
        try:
            raw = self.sensor.range
            if raw and raw > 0 and raw < 2000:
                filtered_mm = self.filter.apply(raw)
                displacement_mm = self.reference_zero - filtered_mm
                if displacement_mm > 30:
                    displacement_mm = 30
                elif displacement_mm < -30:
                    displacement_mm = -30
                displacement_cm = int(round(displacement_mm / 10))
                return displacement_cm
            return 0
        except Exception as e:
            print(f"Displacement error: {e}")
            return 0

# ----------------------------
# Flask App with SocketIO
# ----------------------------
app = Flask(__name__)
app.config['SECRET_KEY'] = 'respiratory_monitor_secret'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

sensor = RespiratorySensor()
streaming = False

class DummyPatient:
    def __init__(self):
        self.heart_rate = 72
        self.breathing_rate = 16
        self.temperature = 36.8
        self.spo2 = 98
        self.systolic = 118
        self.diastolic = 78

dummy_patient = DummyPatient()

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

@socketio.on('connect')
def handle_connect(auth=None):
    print('Client connected')
    emit('calibration_status', {'calibrated': sensor.calibrated})
    emit('patient_data', {
        'heart_rate': dummy_patient.heart_rate,
        'breathing_rate': dummy_patient.breathing_rate,
        'temperature': dummy_patient.temperature,
        'spo2': dummy_patient.spo2,
        'blood_pressure': f"{dummy_patient.systolic}/{dummy_patient.diastolic}"
    })

@socketio.on('calibrate')
def handle_calibration():
    print("Starting FAST calibration (5 samples only)...")
    success = sensor.calibrate_zero()
    emit('calibration_status', {'calibrated': success})
    if success:
        zero_cm = int(round(sensor.reference_zero / 10)) if sensor.reference_zero else 0
        emit('calibration_complete', {
            'zero_value': zero_cm,
            'message': f"Zero set to {zero_cm} cm"
        })
    return success

@socketio.on('start_streaming')
def handle_start_streaming():
    global streaming
    streaming = True
    print("\n" + "=" * 50)
    print("STREAMING STARTED - Readings in cm (INTEGERS)")
    print("=" * 50 + "\n")
    
    def stream_data():
        last_debug_time = time.time()
        frame_count = 0
        
        while streaming:
            displacement = sensor.get_displacement()
            
            if displacement >= 1:
                phase = "INHALING"
            elif displacement <= -1:
                phase = "EXHALING"
            else:
                phase = "PAUSE"
            
            socketio.emit('sensor_data', {
                'displacement': displacement,
                'phase': phase,
                'timestamp': time.time()
            })
            
            dummy_patient.breathing_rate = 12 + abs(displacement) * 2
            socketio.emit('patient_data', {
                'heart_rate': dummy_patient.heart_rate + np.random.randn() * 2,
                'breathing_rate': max(8, min(25, dummy_patient.breathing_rate)),
                'temperature': dummy_patient.temperature + np.random.randn() * 0.1,
                'spo2': min(100, max(90, dummy_patient.spo2 + np.random.randn() * 0.5)),
                'blood_pressure': f"{dummy_patient.systolic + int(np.random.randn() * 3)}/{dummy_patient.diastolic + int(np.random.randn() * 2)}"
            })
            
            frame_count += 1
            current_time = time.time()
            if current_time - last_debug_time >= 2.0:
                print(f"[Stream] Displacement: {displacement:+d} cm | Phase: {phase} | Rate: {frame_count/2:.1f} Hz")
                last_debug_time = current_time
                frame_count = 0
            
            time.sleep(0.05)
    
    socketio.start_background_task(stream_data)

@socketio.on('stop_streaming')
def handle_stop_streaming():
    global streaming
    streaming = False
    print("\nSTREAMING STOPPED\n")

if __name__ == '__main__':
    print("\n" + "=" * 60)
    print(" RESPIRATORY MONITOR SERVER - FAST CALIBRATION")
    print(" ONLY 5 SAMPLES FOR CALIBRATION!")
    print(" READINGS IN CENTIMETERS (cm) - INTEGER VALUES")
    print("=" * 60)
    
    if sensor.sensor:
        print("✓ Sensor detected")
        try:
            test_mm = sensor.sensor.range
            if test_mm:
                print(f"  Test reading: {test_mm:.1f} mm ({int(round(test_mm/10))} cm)")
        except:
            pass
    else:
        print("⚠ WARNING: Sensor not detected!")
    
    print("\nAccess the dashboard at:")
    print("  • http://localhost:5000")
    print("  • http://<YOUR_RASPBERRY_PI_IP>:5000")
    print("=" * 60)
    print("\nINSTRUCTIONS:")
    print("1. Click 'Calibrate Zero' - ONLY 5 SAMPLES (takes <1 second!)")
    print("2. Click 'Start Monitoring' to begin")
    print("=" * 60 + "\n")
    
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
