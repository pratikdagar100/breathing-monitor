#!/usr/bin/env python3
"""
Patient Display Server – runs on port 8000
Mirrors the main dashboard's respiratory visualizer + relay timer only.
Laid out as 2 fixed panes (visualizer | timer) sized to fit an 800x480 screen.
"""

from flask import Flask, render_template_string
import webbrowser

app = Flask(__name__)

PATIENT_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=800, initial-scale=1.0, user-scalable=no">
    <title>Patient Respiratory Monitor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.socket.io/4.5.4/socket.io.min.js"></script>
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        :root {
            --bg-base: #060e1a;
            --bg-panel: #0b1628;
            --border: rgba(0,212,200,0.15);
            --border-dim: rgba(255,255,255,0.06);
            --teal: #00d4c8;
            --green: #00e676;
            --red: #ff3b5c;
            --amber: #ffb547;
            --text-primary: #e8f0fe;
            --text-secondary: #8faac8;
            --text-muted: #4a6080;
            --font-mono: 'JetBrains Mono', monospace;
            --font-ui: 'Inter', sans-serif;
        }
        html, body {
            width: 800px; height: 480px;
            overflow: hidden;
            font-family: var(--font-ui);
            background: var(--bg-base);
            color: var(--text-primary);
        }
        .screen {
            position: relative;
            width: 800px; height: 480px;
            display: flex;
            flex-direction: column;
        }
        .topbar {
            display: flex; align-items: center; justify-content: space-between;
            height: 34px; min-height: 34px;
            padding: 0 14px;
            border-bottom: 1px solid var(--border-dim);
            background: var(--bg-panel);
        }
        .topbar-title {
            display: flex; align-items: center; gap: 8px;
            font-family: var(--font-mono); font-size: 0.65rem;
            letter-spacing: 0.1em; text-transform: uppercase;
            color: var(--teal);
        }
        .status-dot {
            width: 7px; height: 7px; border-radius: 50%;
            background: var(--text-muted);
            transition: background 0.3s;
        }
        .status-dot.connected { background: var(--green); box-shadow: 0 0 8px var(--green); }
        .topbar-zero {
            font-family: var(--font-mono); font-size: 0.6rem;
            color: var(--text-muted);
        }

        /* ── Two panes ── */
        .panes {
            flex: 1;
            display: flex;
            min-height: 0;
        }
        .pane {
            display: flex; flex-direction: column;
            min-height: 0;
        }
        .pane-left {
            flex: 0 0 480px;
            border-right: 1px solid var(--border-dim);
        }
        .pane-right {
            flex: 1;
        }
        .pane-label {
            display: flex; align-items: center; gap: 6px;
            font-family: var(--font-mono); font-size: 0.6rem;
            letter-spacing: 0.1em; text-transform: uppercase;
            color: var(--text-secondary);
            padding: 8px 0 4px;
            justify-content: center;
        }

        /* ── Visualizer pane ── */
        .cylinder-wrapper {
            position: relative;
            flex: 1;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
        }
        .lung-glow-ring {
            position: absolute;
            width: 220px; height: 320px;
            border: 1px solid rgba(0,212,200,0.12);
            border-radius: 110px / 60px;
            box-shadow: 0 0 30px rgba(0,212,200,0.06), inset 0 0 30px rgba(0,212,200,0.03);
            pointer-events: none;
        }
        .cylinder {
            position: relative;
            width: 170px; height: 280px;
            background: linear-gradient(180deg, #0a1f35 0%, #0d2a48 40%, #0a1f35 100%);
            border-radius: 85px / 42px;
            box-shadow: inset -5px 0 16px rgba(0,0,0,0.5), inset 5px 0 10px rgba(0,212,200,0.06), 0 8px 30px rgba(0,0,0,0.4);
            overflow: hidden;
        }
        .cylinder::after {
            content: '';
            position: absolute; left: 20px; top: 0; bottom: 0; width: 16px;
            background: linear-gradient(180deg, rgba(0,212,200,0.12) 0%, rgba(0,212,200,0.05) 50%, rgba(0,212,200,0.12) 100%);
            border-radius: 50%;
        }
        .cylinder-cap-top {
            position: absolute; top: -14px; left: 50%; transform: translateX(-50%);
            width: 170px; height: 28px;
            background: radial-gradient(ellipse at center, rgba(0,212,200,0.35) 0%, rgba(0,212,200,0.05) 70%, transparent 100%);
            border-radius: 50%;
        }
        .cylinder-cap-bottom {
            position: absolute; bottom: -14px; left: 50%; transform: translateX(-50%);
            width: 170px; height: 28px;
            background: radial-gradient(ellipse at center, rgba(0,0,0,0.6) 0%, transparent 70%);
            border-radius: 50%;
        }
        .cylinder-ticks {
            position: absolute; right: 10px; top: 24px; bottom: 24px;
            display: flex; flex-direction: column; justify-content: space-between;
        }
        .cylinder-tick { width: 8px; height: 1px; background: rgba(0,212,200,0.2); }
        .moving-ring {
            position: absolute;
            width: 188px; height: 11px; left: -9px;
            background: linear-gradient(90deg, transparent, var(--teal), var(--teal), transparent);
            border-radius: 6px;
            transition: top 0.05s linear, background 0.2s ease, box-shadow 0.2s ease;
            box-shadow: 0 0 16px rgba(0,212,200,0.9), 0 0 36px rgba(0,212,200,0.4);
            z-index: 10;
        }
        .moving-ring.over-limit {
            background: linear-gradient(90deg, transparent, var(--red), var(--red), transparent);
            box-shadow: 0 0 16px rgba(255,59,92,0.9), 0 0 36px rgba(255,59,92,0.4);
        }
        .viz-threshold-line {
            position: absolute;
            left: -9px;
            width: 188px;
            height: 0;
            border-top: 2px dashed;
            z-index: 8;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.2s;
        }
        .viz-threshold-line.active { opacity: 1; }
        .viz-threshold-line.inhale { border-color: var(--green); }
        .viz-threshold-line.exhale { border-color: var(--red); }
        .viz-threshold-label {
            position: absolute;
            right: -42px; top: -7px;
            font-family: var(--font-mono);
            font-size: 0.5rem;
            white-space: nowrap;
            color: var(--text-secondary);
            background: var(--bg-base);
            padding: 0 3px;
        }
        .cylinder-scale {
            position: absolute; right: -38px; top: 0; bottom: 0;
            display: flex; flex-direction: column; justify-content: space-between;
            padding: 10px 0;
        }
        .scale-label {
            font-family: var(--font-mono); font-size: 0.55rem;
            color: var(--text-muted); line-height: 1;
        }
        .current-display {
            font-family: var(--font-mono); font-size: 1.3rem; font-weight: 600;
            color: var(--text-secondary);
            letter-spacing: 0.04em;
            padding-bottom: 8px;
        }
        .current-display span { color: var(--teal); }

        /* ── Timer pane ── */
        .timer-pane {
            flex: 1;
            display: flex; flex-direction: column;
            align-items: center; justify-content: center;
            gap: 10px;
        }
        .timer-ring-wrap {
            position: relative;
            display: flex; align-items: center; justify-content: center;
        }
        .timer-ring-svg {
            position: absolute;
            width: 160px; height: 160px;
            transform: rotate(-90deg);
        }
        .timer-ring-bg { fill: none; stroke: rgba(255,255,255,0.05); stroke-width: 3; }
        .timer-ring-fill {
            fill: none; stroke: var(--teal); stroke-width: 3; stroke-linecap: round;
            stroke-dasharray: 440; stroke-dashoffset: 440;
            transition: stroke 0.3s;
        }
        .timer-ring-fill.running { stroke: var(--green); }
        .timer-ring-fill.stopped { stroke: var(--amber); }
        .timer-display {
            font-family: var(--font-mono); font-size: 2.4rem; font-weight: 700;
            letter-spacing: 0.02em;
            font-variant-numeric: tabular-nums;
            transition: color 0.3s, text-shadow 0.3s;
        }
        .timer-display.running { color: var(--green); text-shadow: 0 0 22px rgba(0,230,118,0.5); }
        .timer-display.stopped { color: var(--amber); text-shadow: 0 0 22px rgba(255,181,71,0.5); }
        .timer-display.idle { color: rgba(255,255,255,0.15); text-shadow: none; }
        .timer-state-badge {
            padding: 4px 14px; border-radius: 18px;
            font-family: var(--font-mono); font-size: 0.6rem; font-weight: 700;
            letter-spacing: 0.12em; text-transform: uppercase;
        }
        .timer-state-badge.idle    { background: rgba(255,255,255,0.05); color: var(--text-muted); border: 1px solid var(--border-dim); }
        .timer-state-badge.running { background: rgba(0,230,118,0.15); color: var(--green); border: 1px solid rgba(0,230,118,0.35); }
        .timer-state-badge.stopped { background: rgba(255,181,71,0.15); color: var(--amber); border: 1px solid rgba(255,181,71,0.35); }
        .timer-sub {
            font-family: var(--font-mono); font-size: 0.58rem;
            color: var(--text-muted); text-align: center;
            max-width: 220px; line-height: 1.5;
        }
    </style>
</head>
<body>
    <div class="screen">
        <div class="topbar">
            <div class="topbar-title">
                <i class="fas fa-lungs" style="color:var(--teal);"></i>
                Patient Monitor
                <span class="status-dot" id="statusDot"></span>
            </div>
            <div class="topbar-zero" id="zeroDisplay">Zero: -- cm</div>
        </div>

        <div class="panes">
            <div class="pane pane-left">
                <div class="pane-label"><i class="fas fa-wind"></i>&nbsp;Respiratory Motion Visualizer</div>
                <div class="cylinder-wrapper">
                    <div class="lung-glow-ring"></div>
                    <div class="cylinder">
                        <div class="cylinder-ticks">
                            <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                            <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                            <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                            <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                            <div class="cylinder-tick"></div><div class="cylinder-tick"></div>
                            <div class="cylinder-tick"></div>
                        </div>
                        <div class="viz-threshold-line inhale" id="vizThresholdInhaleMin">
                            <span class="viz-threshold-label" id="vizThresholdInhaleMinLabel">Inhale Min</span>
                        </div>
                        <div class="viz-threshold-line inhale" id="vizThresholdInhaleMax">
                            <span class="viz-threshold-label" id="vizThresholdInhaleMaxLabel">Inhale Max</span>
                        </div>
                        <div class="viz-threshold-line exhale" id="vizThresholdExhaleMin">
                            <span class="viz-threshold-label" id="vizThresholdExhaleMinLabel">Exhale Min</span>
                        </div>
                        <div class="viz-threshold-line exhale" id="vizThresholdExhaleMax">
                            <span class="viz-threshold-label" id="vizThresholdExhaleMaxLabel">Exhale Max</span>
                        </div>
                        <div class="moving-ring" id="movingRing" style="top:50%;"></div>
                    </div>
                    <div class="cylinder-cap-top"></div>
                    <div class="cylinder-cap-bottom"></div>
                    <div class="cylinder-scale">
                        <span class="scale-label">+4</span>
                        <span class="scale-label">+2</span>
                        <span class="scale-label"> 0</span>
                        <span class="scale-label">-2</span>
                        <span class="scale-label">-4</span>
                    </div>
                </div>
                <div class="current-display" style="align-self:center;"><span id="currentDispVal">0</span> cm</div>
            </div>

            <div class="pane pane-right">
                <div class="pane-label"><i class="fas fa-stopwatch"></i>&nbsp;Relay Timer</div>
                <div class="timer-pane">
                    <div class="timer-ring-wrap">
                        <svg class="timer-ring-svg" viewBox="0 0 160 160">
                            <circle class="timer-ring-bg" cx="80" cy="80" r="70"/>
                            <circle class="timer-ring-fill" id="timerRingFill" cx="80" cy="80" r="70"/>
                        </svg>
                        <div class="timer-display idle" id="timerDisplay">00:00.0</div>
                    </div>
                    <div class="timer-state-badge idle" id="timerBadge">IDLE</div>
                    <div class="timer-sub" id="timerSub">Waiting for relay to activate.</div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // ── Socket connection to main backend ──
        const socket = io('http://localhost:5000');

        // ── DOM refs ──
        const statusDot = document.getElementById('statusDot');
        const movingRing = document.getElementById('movingRing');
        const currentDispVal = document.getElementById('currentDispVal');
        const zeroDisplay = document.getElementById('zeroDisplay');

        // Threshold line elements
        const inhaleMinLine = document.getElementById('vizThresholdInhaleMin');
        const inhaleMaxLine = document.getElementById('vizThresholdInhaleMax');
        const exhaleMinLine = document.getElementById('vizThresholdExhaleMin');
        const exhaleMaxLine = document.getElementById('vizThresholdExhaleMax');
        const inhaleMinLabel = document.getElementById('vizThresholdInhaleMinLabel');
        const inhaleMaxLabel = document.getElementById('vizThresholdInhaleMaxLabel');
        const exhaleMinLabel = document.getElementById('vizThresholdExhaleMinLabel');
        const exhaleMaxLabel = document.getElementById('vizThresholdExhaleMaxLabel');

        // ── Visualizer constants ──
        const VIZ_MAX_D = 4;
        const VIZ_MIN_TOP = 36;   // top for +4 cm
        const VIZ_MAX_TOP = 224;  // top for -4 cm

        function vizPositionForValue(v) {
            const clamped = Math.max(-VIZ_MAX_D, Math.min(VIZ_MAX_D, v));
            const norm = (clamped + VIZ_MAX_D) / (2 * VIZ_MAX_D);
            return VIZ_MAX_TOP - (norm * (VIZ_MAX_TOP - VIZ_MIN_TOP));
        }

        // ── Threshold storage — each phase band is independent, exactly as
        // it is broadcast from the dashboard. Both bands are tracked at all
        // times regardless of which one was set most recently. ──
        let thresholds = {
            inhale: { min: null, max: null },
            exhale: { min: null, max: null }
        };

        function updateThresholdLines() {
            function setLine(el, labelEl, value, labelPrefix) {
                if (value === null || value === undefined) {
                    el.classList.remove('active');
                    return;
                }
                el.style.top = `${vizPositionForValue(value)}px`;
                el.classList.add('active');
                labelEl.textContent = `${labelPrefix} ${value.toFixed(1)} cm`;
            }
            const inh = thresholds.inhale;
            const exh = thresholds.exhale;
            // Inhale band is positive displacement, exhale band is negative.
            setLine(inhaleMinLine, inhaleMinLabel, inh.min !== null ? inh.min : null, 'Inhale Min');
            setLine(inhaleMaxLine, inhaleMaxLabel, inh.max !== null ? inh.max : null, 'Inhale Max');
            setLine(exhaleMinLine, exhaleMinLabel, exh.min !== null ? -exh.min : null, 'Exhale Min');
            setLine(exhaleMaxLine, exhaleMaxLabel, exh.max !== null ? -exh.max : null, 'Exhale Max');
        }

        // ── Over-limit check — a value is judged by its OWN sign's band,
        // never by "whichever phase was set last". Positive displacement
        // checks against inhale.max, negative checks against exhale.max. ──
        function isPastMaxLimit(v) {
            if (v >= 0) {
                const m = thresholds.inhale.max;
                return (m !== null && m !== undefined) && v > m;
            } else {
                const m = thresholds.exhale.max;
                return (m !== null && m !== undefined) && Math.abs(v) > m;
            }
        }

        // ── Socket events ──
        socket.on('connect', () => {
            statusDot.className = 'status-dot connected';
            socket.emit('get_relay_status');
        });

        socket.on('disconnect', () => {
            statusDot.className = 'status-dot';
        });

        socket.on('calibration_complete', (data) => {
            if (data && data.zero_value !== undefined) {
                zeroDisplay.textContent = `Zero: ${data.zero_value} cm`;
            }
            resetTimer();
        });

        socket.on('calibration_status', (data) => {
            if (data.calibrated && data.zero_value !== undefined) {
                zeroDisplay.textContent = `Zero: ${data.zero_value} cm`;
                resetTimer();
            } else {
                zeroDisplay.textContent = 'Zero: -- cm';
            }
        });

        socket.on('sensor_data', (data) => {
            if (data.displacement !== undefined) {
                const disp = data.displacement;
                movingRing.style.top = `${vizPositionForValue(disp)}px`;
                movingRing.classList.toggle('over-limit', isPastMaxLimit(disp));
                currentDispVal.textContent = Math.round(disp);
            }
        });

        // ── Mirror relay timer state from the backend — display only,
        // never initiates timer changes itself ──
        let lastTimerActive = false;
        socket.on('relay_status_update', (data) => {
            const active = !!data.timer_active;
            if (active && !lastTimerActive) startTimer();
            else if (!active && lastTimerActive) stopTimer();
            lastTimerActive = active;
        });

        // ── 15-minute session limit reached ──
        socket.on('session_expired', () => {
            zeroDisplay.textContent = 'Zero: -- cm';
            movingRing.style.top = `${vizPositionForValue(0)}px`;
            movingRing.classList.remove('over-limit');
            stopTimer();
            resetTimer();
        });

        // ── Threshold updates from dashboard — each phase updates its own
        // band independently; the other phase's band is left untouched. ──
        socket.on('thresholds_updated', (data) => {
            const phase = data.phase;
            if (phase === 'inhale' || phase === 'exhale') {
                thresholds[phase].min = data.min;
                thresholds[phase].max = data.max;
                updateThresholdLines();
            }
        });

        /* ── Timer logic — mirrors dashboard's Relay Timer pane ── */
        let timerRunning = false, timerStartMs = null, timerFrozenValue = null, timerRAF = null;

        function fmtTime(ms) {
            const total = ms / 1000;
            const m = Math.floor(total / 60);
            const s = Math.floor(total % 60);
            const d = Math.floor((total % 1) * 10);
            return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${d}`;
        }

        function startTimer() {
            timerFrozenValue = null;
            timerStartMs = Date.now();
            timerRunning = true;
            const el = document.getElementById('timerDisplay');
            const bdg = document.getElementById('timerBadge');
            const sub = document.getElementById('timerSub');
            const ring = document.getElementById('timerRingFill');
            el.className = 'timer-display running';
            bdg.className = 'timer-state-badge running';
            bdg.textContent = 'RUNNING';
            ring.className = 'timer-ring-fill running';
            sub.textContent = 'Relay is active.';
            function tick() {
                if (!timerRunning) return;
                el.textContent = fmtTime(Date.now() - timerStartMs);
                timerRAF = requestAnimationFrame(tick);
            }
            cancelAnimationFrame(timerRAF);
            timerRAF = requestAnimationFrame(tick);
        }

        function stopTimer() {
            timerRunning = false;
            cancelAnimationFrame(timerRAF);
            const el = document.getElementById('timerDisplay');
            const bdg = document.getElementById('timerBadge');
            const sub = document.getElementById('timerSub');
            const ring = document.getElementById('timerRingFill');
            if (timerStartMs) { timerFrozenValue = Date.now() - timerStartMs; el.textContent = fmtTime(timerFrozenValue); }
            el.className = timerFrozenValue ? 'timer-display stopped' : 'timer-display idle';
            bdg.className = timerFrozenValue ? 'timer-state-badge stopped' : 'timer-state-badge idle';
            bdg.textContent = timerFrozenValue ? 'STOPPED' : 'IDLE';
            ring.className = timerFrozenValue ? 'timer-ring-fill stopped' : 'timer-ring-fill';
            sub.textContent = timerFrozenValue ? 'Showing last relay-on duration.' : 'Waiting for relay to activate.';
        }

        function resetTimer() {
            timerRunning = false; timerStartMs = null; timerFrozenValue = null;
            cancelAnimationFrame(timerRAF);
            const el = document.getElementById('timerDisplay');
            const bdg = document.getElementById('timerBadge');
            const sub = document.getElementById('timerSub');
            const ring = document.getElementById('timerRingFill');
            el.textContent = '00:00.0';
            el.className = 'timer-display idle';
            bdg.className = 'timer-state-badge idle';
            bdg.textContent = 'IDLE';
            ring.className = 'timer-ring-fill';
            ring.style.strokeDashoffset = '440';
            sub.textContent = 'Waiting for relay to activate.';
            lastTimerActive = false;
        }

        // ── Initial state ──
        movingRing.style.top = `${vizPositionForValue(0)}px`;
        updateThresholdLines();
        resetTimer();
    </script>
</body>
</html>
"""

@app.route('/')
def patient_display():
    return render_template_string(PATIENT_HTML)

if __name__ == '__main__':
    print("\n" + "=" * 50)
    print(" PATIENT DISPLAY SERVER")
    print(" Serving on http://localhost:8000")
    print(" 2-pane layout (visualizer | timer) — fits 800x480")
    print(" Ensure the main backend is running on port 5000")
    print("=" * 50 + "\n")
    webbrowser.open('http://localhost:8000')
    app.run(host='0.0.0.0', port=8000, debug=False)
